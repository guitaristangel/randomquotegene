document.getElementById('loadQuote').addEventListener("click", printQuote, false);
var quotes = [
  
  {
    'quote': 'I fear not the man who has practiced 10000 kicks once, but I fear the man who has practiced one kick 10000 times',
    'source': 'Bruce Lee',
    'citation': 'Quotable Quote',
    'year': '1940 - 1973',
    'tags': 'Inspirational Push',
 },  
    
 {
      'quote': 'Do not pray for an easy life, pray for the strength to endure a difficult one',
      'source': 'Bruce Lee',
      'citation': '',
      'year': '1940 - 1973',
      'tags':'Self-Esteem',
 },
   {
    'quote': 'We accept the love we think we deserve',
    'source': 'Stepehn Chbosky',
    'citation':'The Perks Of Being A Wallflower',
    'year': '1999',
     'tags': 'Love',
   },
   {
    'quote': 'Love is suffering. One side always loves more.',
    'source': 'Catherine Deneuve',
    'citation': 'Brainy Quote',
    'year': '2017',
     'tags': 'Love',
   },
   {
    'quote': 'There is only one happiness in this life, to love and be loved',
    'source': 'George Sand',
    'citation': 'Brainy Quote',
    'year': '',
     'tags': '',
   },
   {
    'quote': 'Repetition is the mother of skill',
    'source': 'Tony robbins',
    'citation': 'AZ Quotes',
    'year': '2017',
     'tags': 'Life skills',
   },
   {
    'quote': 'You Can Develop Any Habit Or Thought Or Behavior That You Consider Desirable Or Necessary',
    'source': 'Brian Tracy',
    'citation': 'Life Goals',
    'year': '2017',
     'tags': 'Personal Growth',
   },
  ];

var numR, qC,
    qNum = quotes.length,
    aR = [];
function printQuote() {
    clearInterval(qC);
    if ( qNum === aR.length  ) {
        aR = [];
    }
    var color = "#000000".replace(/0/g,function(){return (~~(Math.random()*4)).toString(4);});
    document.body.style.backgroundColor = color;
  
    var qObj = getRandomQuote();
    var print = ' <h1 class="quote">' + qObj.quote + '</h1>';
    print += '<h1 class="source">' + qObj.source;
    if ( qObj.citation !== '' ) 
    {
        print += '<span class="citation">' + qObj.citation + '</span> ';
    }
    if ( qObj.year !== '' ) 
    {
        print += '<span class="year">' + qObj.year + '</span> ';
    }
    print += '</h1>';//adding just in case
    if ( qObj.tags !== '' )
    {
        print += '<h1>' + qObj.tags + '</h1> ';
    }
   var current = document.getElementById('quote-box').innerHTML;
    document.getElementById('quote-box').innerHTML =
    document.getElementById('quote-box').innerHTML.replace( current, print);
    start();
}

function getRandomQuote() {

    do {
        numR =  Math.floor( Math.random() * qNum );
    } while ( aR.includes(numR) );
    aR.push(numR);
    return quotes[ numR ];
}

function start() {
    qC = setInterval(function () {

        printQuote();
    }, 30000);

}
